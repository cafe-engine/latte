function cafe.load() end
function cafe.update(dt) end
function cafe.draw() end